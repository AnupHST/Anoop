# Encharge.io Setup
Automating email journeys.