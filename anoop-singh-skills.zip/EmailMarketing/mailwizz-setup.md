# MailWizz Setup
Installation and configuration guide.