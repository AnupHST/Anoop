# GCP Instance Setup
Steps to configure a GCP VM instance.