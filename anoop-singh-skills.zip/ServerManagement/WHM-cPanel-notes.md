# WHM/cPanel Notes
Common tasks and configurations.