# Nginx vs Apache
Comparison and performance tips.